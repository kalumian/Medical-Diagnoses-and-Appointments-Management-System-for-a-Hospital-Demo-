﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hastane.Business_Layer;
namespace Hastane
{
    public partial class YeniHasta : Form
    {
        Main.enMode Mode {  get; set; }
        private clsHasta hasta {  get; set; }
        public YeniHasta()
        {
            InitializeComponent();
            Store.setDataIntoComboBox(comboCinsiyet, Store.Cinsiyetler, "cinsiyet_Adi", "cinsiyet_Id");
            Store.setDataIntoComboBox(comboKan, Store.Kan_Grublari, "kan_grubu_Adi", "kan_grubu_Id");
            Store.setDataIntoComboBox(comboMedeni, Store.Medeni_durumlari, "medeni_durum_Adi", "medeni_durum_Id");
            Store.setDataIntoComboBox(comboMeslek, Store.Meslekler, "meslek_Adi", "meslek_Id");
            Store.setDataIntoComboBox(comboEgitim, Store.Egitim_Durumlari, "egitim_durumu_Adi", "egitim_durumu_Id");
            Mode = Main.enMode.Add;
            comboCinsiyet.SelectedIndex = 0;
            comboEgitim.SelectedIndex = 0;
            comboKan.SelectedIndex = 0;
            comboMedeni.SelectedIndex = 0;
            comboMeslek.SelectedIndex = 0;
        }
        public YeniHasta(string hasta_Tc)
        {
            InitializeComponent();
            Store.setDataIntoComboBox(comboCinsiyet, Store.Cinsiyetler, "cinsiyet_Adi", "cinsiyet_Id");
            Store.setDataIntoComboBox(comboKan, Store.Kan_Grublari, "kan_grubu_Adi", "kan_grubu_Id");
            Store.setDataIntoComboBox(comboMedeni, Store.Medeni_durumlari, "medeni_durum_Adi", "medeni_durum_Id");
            Store.setDataIntoComboBox(comboMeslek, Store.Meslekler, "meslek_Adi", "meslek_Id");
            Store.setDataIntoComboBox(comboEgitim, Store.Egitim_Durumlari, "egitim_durumu_Adi", "egitim_durumu_Id");
            Mode = Main.enMode.Update;
            hasta = clsHasta.Find(hasta_Tc);
            comboCinsiyet.SelectedIndex = hasta.cinsiyet_Id;
            comboEgitim.SelectedIndex = hasta.egitim_durumu_Id;
            comboKan.SelectedIndex = hasta.kan_grubu_Id;
            comboMedeni.SelectedIndex = hasta.medeni_durum_Id;
            comboMeslek.SelectedIndex = hasta.meslek_Id ;
            txtAdi.Text = hasta.hasta_Adi;
            txtSoaydi.Text = hasta.hasta_Soyadi;
            txtTelefon.Text = hasta.telefon_no;
            txtTc.Text = hasta.hasta_Tc;
            txtAdress.Text = hasta.adres;
            txtTc.Enabled = false;
            title.Text = "Hasta bilgilerini değiştirin";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!clsHasta.isExist(txtTc.Text) || Mode == Main.enMode.Update)
            {
                if
                    (
                    string.IsNullOrEmpty(txtAdi.Text) ||
                    string.IsNullOrEmpty(txtAdress.Text) ||
                    string.IsNullOrEmpty(txtSoaydi.Text) ||
                    string.IsNullOrEmpty(txtTc.Text) ||
                    string.IsNullOrEmpty(txtTelefon.Text) ||
                    txtTc.Text.Length != 11 ||
                    comboCinsiyet.SelectedIndex == 0 ||
                    comboEgitim.SelectedIndex == 0 ||
                    comboKan.SelectedIndex == 0 ||
                    comboMeslek.SelectedIndex == 0 ||
                    comboMedeni.SelectedIndex == 0
                    )
                {
                    Store.MessageError("Girişleri kontrol edin");
                }
                else
                {
                    if
                        (
                        comboCinsiyet.SelectedItem is Tuple<string, string> select_comboCinsiyet &&
                        comboEgitim.SelectedItem is Tuple<string, string> select_comboEgitim &&
                        comboKan.SelectedItem is Tuple<string, string> select_comboKan &&
                        comboMeslek.SelectedItem is Tuple<string, string> select_comboMeslek &&
                        comboMedeni.SelectedItem is Tuple<string, string> select_comboMedeni
                        )
                    {
                        if (this.Mode == Main.enMode.Add) hasta = new clsHasta();
                        hasta.hasta_Tc = txtTc.Text;
                        hasta.hasta_Adi = txtAdi.Text;
                        hasta.hasta_Soyadi = txtSoaydi.Text;
                        hasta.adres = txtAdress.Text;
                        hasta.dogum_tarihi = dateTimePicker1.Value;
                        hasta.telefon_no = txtTelefon.Text;
                        hasta.cinsiyet_Id = int.Parse(select_comboCinsiyet.Item2);
                        hasta.egitim_durumu_Id = int.Parse(select_comboEgitim.Item2);
                        hasta.kan_grubu_Id = int.Parse(select_comboKan.Item2);
                        hasta.meslek_Id = int.Parse(select_comboMeslek.Item2);
                        hasta.medeni_durum_Id = int.Parse(select_comboMedeni.Item2);
                        if (hasta.Save())
                        {
                            Store.MessageCorrect(this.Mode == Main.enMode.Add ? "Hasta başarıyla eklendi" : "Hasta bilgileri başarıyla değiştirildi");
                        }
                        else
                        {
                            Store.MessageError("Girişleri kontrol edin");
                        }
                    }
                    else
                    {
                        Store.MessageError("Girişleri kontrol edin");
                    }

                }
            }
            else
            {
                Store.MessageError($"Hasta ID numarası {txtTc.Text} zaten kayıtlı");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboKan_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
