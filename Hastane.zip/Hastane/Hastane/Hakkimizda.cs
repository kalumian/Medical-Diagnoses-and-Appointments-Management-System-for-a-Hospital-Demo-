﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class Hakkimizda : Form
    {
        public Hakkimizda()
        {
            InitializeComponent();
            LoadDataIntoDataGridView();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
        private void LoadDataIntoDataGridView()
        {
            // إنشاء DataTable
            DataTable table = new DataTable();

            // إضافة أعمدة إلى DataTable
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("ID", typeof(string));

            // إضافة صفوف إلى DataTable
            table.Rows.Add("SAKHR MOHAMMED AL MASNAEA", "2111505218");
            table.Rows.Add("MUHAMMED YILDIZ", "201505044");
            table.Rows.Add("RIDVAN BÜYÜKKAYA", "2111505056");
            table.Rows.Add("Muhammad Kalumian", "2111505201");

            // تعيين DataTable كمصدر بيانات لـ DataGridView
            dataGridView1.DataSource = table;

            // جعل عرض الأعمدة قابلاً للتمدد حسب طول محتوى كل عمود
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
