﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hastane.Business_Layer;
namespace Hastane
{
    public partial class Hastalar : Form
    {
        public Hastalar()
        {
            InitializeComponent();
            _Load();
            dataGridViewWithSearchControl1.Strip = contextMenuStrip1;
        }
        private void _Load()
        {
            dataGridViewWithSearchControl1.InitializeDataGridViewComponent(clsHasta.GetAllHastalar());

        }
        private string Hasta_Tc_Giter()
        {
            return dataGridViewWithSearchControl1.SelectedRows[0].Cells["Hasta TC"].Value.ToString();

        }
        private void bilgileriGörüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string HastaTc = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Hasta TC"].Value.ToString();
            new HastaInfo(HastaTc).ShowDialog();
        }

        private void guncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new YeniHasta(Hasta_Tc_Giter()).ShowDialog();
            _Load();
        }

        private void dataGridViewWithSearchControl1_OnObjectAdded(object obj)
        {
            new YeniHasta().ShowDialog();
            _Load();
        }

        private void yeniHastaEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new YeniHasta().ShowDialog();
            _Load();
        }

        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!clsHasta.HasMuayene(Hasta_Tc_Giter()))
            {
                 if (clsHasta.DeleteHastaByTc(Hasta_Tc_Giter()))
                {
                    Store.MessageCorrect("Hasta başarıyla silindi");
                }
                else
                {
                    Store.MessageError("Hasta silinemeyen bir hata oluştu");
                }
            }
            else
            {
                Store.MessageError("Bu hasta bir Muayene sahip olduğundan silinemez");
            }
            _Load();
        }
    }
}
