﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Collections;

namespace Hastane.Database_Access_Layer
{
    internal class MuyenelerDataAccess
    {
        static public bool DeleteMuayene(int muayene_Id)
        {
            // تعريف متغير لتحديد ما إذا كانت العملية ناجحة أم لا
            bool success = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = "DELETE FROM [Muayene] WHERE [muayene_Id] = @muayene_Id";

                // إعداد وتنفيذ الاستعلام SQL باستخدام SqlCommand
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // تعيين قيمة المعلمة muayene_Id
                    command.Parameters.AddWithValue("@muayene_Id", muayene_Id);

                    // تنفيذ الاستعلام والتحقق من عدد الصفوف المتأثرة
                    int rowsAffected = command.ExecuteNonQuery();

                    // إذا كان هناك صف على الأقل تم حذفه
                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                }
            }

            // إرجاع القيمة المحددة للنجاح أو الفشل
            return success;
        }

        static public bool SetReceteVeTani(int muayene_Id, string Recete, string Tani)
        {
            // تعريف متغير لتحديد ما إذا كانت العملية ناجحة أم لا
            bool success = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = "UPDATE [Muayene] SET [reçete] = @Recete, [tanı] = @Tani WHERE [muayene_Id] = @muayene_Id";

                // إعداد وتنفيذ الاستعلام SQL باستخدام SqlCommand
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // تعيين قيم المعلمات
                    command.Parameters.AddWithValue("@Recete", Recete);
                    command.Parameters.AddWithValue("@Tani", Tani);
                    command.Parameters.AddWithValue("@muayene_Id", muayene_Id);

                    // تنفيذ الاستعلام والتحقق من عدد الصفوف المتأثرة
                    int rowsAffected = command.ExecuteNonQuery();

                    // إذا كان هناك صف على الأقل تم تحديثه
                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                }
            }

            // إرجاع القيمة المحددة للنجاح أو الفشل
            return success;
        }
        static public void GetReceteVeTani(int muayene_Id, ref string Recete, ref string Tani)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = "SELECT [reçete], [tanı] FROM [Muayene] WHERE [muayene_Id] = @muayene_Id";
                // إعداد وتنفيذ الاستعلام SQL باستخدام SqlCommand
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // تعيين قيمة المعلمة muayene_Id
                    command.Parameters.AddWithValue("@muayene_Id", muayene_Id);

                    // استرداد البيانات باستخدام SqlDataReader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // التحقق مما إذا كان هناك بيانات للقراءة
                        if (reader.Read())
                        {
                            // استرداد قيمة ال recete وتعيينها إلى المتغير Recete
                            Recete = reader["reçete"].ToString();

                            // استرداد قيمة ال tani وتعيينها إلى المتغير Tani
                            Tani = reader["tanı"].ToString();
                        }
                    }
                }
            }
        }

        public static DataTable GetAllMuayeneler()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"select * from Muayeneler_view";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static int AddMuayene(
            string hasta_Tc,
            string doktor_Tc,
            DateTime muayene_tarihi
        )
        {
            int muayene_Id = -1;
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"DECLARE @InsertedIDs TABLE (muayene_Id INT);
                     INSERT INTO [Hastane].[dbo].[Muayene] (doktor_Tc, hasta_Tc, tanı, reçete, muayene_tarihi) 
                     OUTPUT INSERTED.muayene_Id INTO @InsertedIDs
                     VALUES (@doktor_Tc, @hasta_Tc, '', '', @muayene_tarihi);
                     SELECT muayene_Id FROM @InsertedIDs;";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@doktor_Tc", doktor_Tc);
            command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);
            command.Parameters.AddWithValue("@muayene_tarihi", muayene_tarihi);
            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    muayene_Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally { connection.Close(); }

            return muayene_Id;
        }
        public static bool UpdateMuayene(
            int muayene_Id,
            string hasta_Tc,
            string doktor_Tc,
            DateTime muayene_tarihi
        )
        {
            bool success = false;
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"UPDATE [Hastane].[dbo].[Muayene] 
                     SET doktor_Tc = @doktor_Tc, hasta_Tc = @hasta_Tc, muayene_tarihi = @muayene_tarihi
                     WHERE muayene_Id = @muayene_Id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@doktor_Tc", doktor_Tc);
            command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);
            command.Parameters.AddWithValue("@muayene_tarihi", muayene_tarihi);
            command.Parameters.AddWithValue("@muayene_Id", muayene_Id);
            try
            {
                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                success = rowsAffected > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally { connection.Close(); }

            return success;
        }
    }
}
