﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Database_Access_Layer
{
    internal class PolikliniklerDataAccess
    {
        public static DataTable GetAllPoliklinikler()
            {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"select * from Poliklinikler_view";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;
        }
    }
}
