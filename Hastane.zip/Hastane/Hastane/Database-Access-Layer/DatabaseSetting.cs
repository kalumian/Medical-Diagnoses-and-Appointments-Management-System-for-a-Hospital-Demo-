﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Database_Access_Layer
{
    internal class DatabaseSetting
    {
        public static string ConnectionString = "Server=.;Database=Hastane;User Id=sa;Password=sa123456;";
    }
}
