﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Database_Access_Layer
{
    internal class MainDatabaseAccess
    {
        static public DataTable getMeslekler()
        {
            return MainDatabaseAccess.getMeslekler();
        }
        // --------------------------------------

        static public DataTable getEgitim_Durumlari()
        {
            return MainDatabaseAccess.getEgitim_Durumlari();
        }
        // --------------------------------------

        static public DataTable getKan_Grublari()
        {
            return MainDatabaseAccess.getKan_Grublari();
        }
        // --------------------------------------

        static public DataTable getMedeni_durumlari()
        {
            return MainDatabaseAccess.getMedeni_durumlari();
        }
        // --------------------------------------
        static public DataTable getCinsiyetler()
        {
            return MainDatabaseAccess.getCinsiyetler();
        }
    }
}
