﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hastane.Business_Layer;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Net;

namespace Hastane.Database_Access_Layer
{
    internal class HastalarDataAccess
    {
        public static bool HasMuayene(string hasta_Tc)
        {
            bool hasMuayene = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM [Muayene] WHERE [hasta_Tc] = @hasta_Tc";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);

                    // تنفيذ الاستعلام واسترداد عدد السجلات
                    int count = (int)command.ExecuteScalar();

                    // إذا كانت عدد السجلات أكبر من صفر، فهذا يعني وجود معاينات للمريض
                    if (count > 0)
                    {
                        hasMuayene = true;
                    }
                }
            }

            return hasMuayene;
        }
        public static bool isHastaExisit(string hasta_Tc)
        {
            bool hasMuayene = false;

            // Replace DatabaseSetting.ConnectionString with your own connection string
            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                string query = "SELECT COUNT(*) FROM [Muayene] WHERE [hasta_Tc] = @hasta_Tc";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);

                    try
                    {
                        connection.Open();

                        // Execute the query and retrieve the number of records
                        int count = (int)command.ExecuteScalar();

                        // If the count is greater than zero, it means there are examinations for the patient
                            if (count > 0)
                        {
                            hasMuayene = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle any exceptions here
                        Console.WriteLine("An error occurred: " + ex.Message);
                    }
                }
            }

            return hasMuayene;
        }
        public static bool _UpdateHasta(
               string hasta_Tc,
               string hasta_Adi,
               string hasta_Soyadi,
               int cinsiyet_Id,
               DateTime dogum_tarihi,
               int medeni_durum_Id,
               int egitim_durumu_Id,
               int meslek_Id,
               int kan_grubu_Id,
               string telefon_no,
               string adres
        )
        {
            bool success = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = @"UPDATE [Hasta] SET 
                        [hasta_Adi] = @hasta_Adi,
                        [hasta_Soyadi] = @hasta_Soyadi,
                        [cinsiyet_Id] = @cinsiyet_Id,
                        [dogum_tarihi] = @dogum_tarihi,
                        [medeni_durum_Id] = @medeni_durum_Id,
                        [egitim_durumu_Id] = @egitim_durumu_Id,
                        [meslek_Id] = @meslek_Id,
                        [kan_grubu_Id] = @kan_grubu_Id,
                        [telefon_no] = @telefon_no,
                        [adres] = @adres
                        WHERE [hasta_Tc] = @hasta_Tc";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);
                    command.Parameters.AddWithValue("@hasta_Adi", hasta_Adi);
                    command.Parameters.AddWithValue("@hasta_Soyadi", hasta_Soyadi);
                    command.Parameters.AddWithValue("@cinsiyet_Id", cinsiyet_Id);
                    command.Parameters.AddWithValue("@dogum_tarihi", dogum_tarihi);
                    command.Parameters.AddWithValue("@medeni_durum_Id", medeni_durum_Id);
                    command.Parameters.AddWithValue("@egitim_durumu_Id", egitim_durumu_Id);
                    command.Parameters.AddWithValue("@meslek_Id", meslek_Id);
                    command.Parameters.AddWithValue("@kan_grubu_Id", kan_grubu_Id);
                    command.Parameters.AddWithValue("@telefon_no", telefon_no);
                    command.Parameters.AddWithValue("@adres", adres);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                }
            }

            return success;
        }
        public static bool DeleteHastaByTc(string hasta_Tc)
        {
            bool success = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = "DELETE FROM [Hasta] WHERE [hasta_Tc] = @hasta_Tc";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                }
            }

            return success;
        }
        public static DataTable GetAllHastalar()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"select * from Hastalar_view";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static bool AddHasta(
            string hasta_Tc,
            string hasta_Adi,
            string hasta_Soyadi,
            int cinsiyet_Id,
            DateTime dogum_tarihi,
            int medeni_durum_Id,
            int egitim_durumu_Id,
            int meslek_Id,
            int kan_grubu_Id,
            string telefon_no,
            string adres
        )
        {
            bool success = false;

            using (SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString))
            {
                connection.Open();
                string query = @"INSERT INTO [Hasta] 
                        ([hasta_Tc], [hasta_Adi], [hasta_Soyadi], [cinsiyet_Id], [dogum_tarihi], 
                        [medeni_durum_Id], [egitim_durumu_Id], [meslek_Id], [kan_grubu_Id], [telefon_no], [adres]) 
                        VALUES (@hasta_Tc, @hasta_Adi, @hasta_Soyadi, @cinsiyet_Id, @dogum_tarihi, 
                        @medeni_durum_Id, @egitim_durumu_Id, @meslek_Id, @kan_grubu_Id, @telefon_no, @adres)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@hasta_Tc", hasta_Tc);
                    command.Parameters.AddWithValue("@hasta_Adi", hasta_Adi);
                    command.Parameters.AddWithValue("@hasta_Soyadi", hasta_Soyadi);
                    command.Parameters.AddWithValue("@cinsiyet_Id", cinsiyet_Id);
                    command.Parameters.AddWithValue("@dogum_tarihi", dogum_tarihi);
                    command.Parameters.AddWithValue("@medeni_durum_Id", medeni_durum_Id);
                    command.Parameters.AddWithValue("@egitim_durumu_Id", egitim_durumu_Id);
                    command.Parameters.AddWithValue("@meslek_Id", meslek_Id);
                    command.Parameters.AddWithValue("@kan_grubu_Id", kan_grubu_Id);
                    command.Parameters.AddWithValue("@telefon_no", telefon_no);
                    command.Parameters.AddWithValue("@adres", adres);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                }
            }

            return success;
        }
        public static bool GetHastaBilgiByTc(
            string hastaTc,
            ref string hasta_Adi,
            ref string hasta_Soyadi,
            ref int cinsiyet_Id,
            ref DateTime dogum_tarihi,
            ref int medeni_durum_Id,
            ref int egitim_durumu_Id,
            ref int meslek_Id,
            ref int kan_grubu_Id,
            ref string telefon_no,
            ref string adres
            ) {
            bool state = false;

            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = "SELECT* FROM Hasta where hasta_Tc = @hastaTc";

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@hastaTc", hastaTc);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    state = true;
                    hasta_Adi = (string)reader["hasta_Adi"];
                    hasta_Soyadi = (string)reader["hasta_Soyadi"];
                    cinsiyet_Id = (int)reader["cinsiyet_Id"];
                    medeni_durum_Id = (int)reader["medeni_durum_Id"];
                    egitim_durumu_Id = (int)reader["egitim_durumu_Id"];
                    meslek_Id = (int)reader["meslek_Id"];
                    kan_grubu_Id = (int)reader["kan_grubu_Id"];
                    dogum_tarihi = (DateTime)reader["dogum_tarihi"];
                    telefon_no = (string)reader["telefon_no"];
                    adres = (string)reader["adres"];
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
                connection.Close();
            }
            return state;
        }
    }
}
