﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Database_Access_Layer
{
    internal class DoktorlarDataAccess
    {
        public static DataTable GetAllDoktorlar()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"select * from Doktorlar_view";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;
        }
        public static DataTable GetAllDoktorByPoliklinik(int poliklinik_Id)
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = @"select doktor_Adi + ' ' + doktor_Soyadi as [Doktor Tum Adi], doktor_Tc from Doktor where Doktor.poliklinik_Id = @poliklinik_Id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("poliklinik_Id", poliklinik_Id);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;
        }
    }
}
