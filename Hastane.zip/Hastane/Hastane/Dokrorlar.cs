﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hastane.Business_Layer;
namespace Hastane
{
    public partial class Dokrorlar : Form
    {
        public Dokrorlar()
        {
            InitializeComponent();
            dataGridViewWithSearchControl1.InitializeDataGridViewComponent(clsDoktor.GetAllDoktor());
            dataGridViewWithSearchControl1.EnableAddButton = false;
        }
    }
}
