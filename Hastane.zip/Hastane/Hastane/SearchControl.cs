﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Hastane
{
    public partial class SearchControl : UserControl
    {
        public delegate void HandleFilterFunctionDelegate(DataView filteredView);
        public event HandleFilterFunctionDelegate FilterFunction;

        private DataGridView _dataGridView; // Define dataGridView control
        private DataTable _originalTable; // Store the original DataTable

        public SearchControl()
        {
            InitializeComponent();
            comboFilterBox.SelectedIndex = 0;
        }

        // Method to set the DataGridView control
        public void InitializeSearchComponent(DataTable table, DataGridView dataGridView)
        {
            this._dataGridView = dataGridView;
            this._originalTable = table.Copy(); // Store a copy of the original DataTable
            _dataGridView.DataSource = _originalTable; // Ensure the DataGridView's DataSource is a DataTable

            SetAllOptions(_originalTable);
        }

        public void AddOption(string newOption)
        {
            comboFilterBox.Items.Add(newOption);
        }

        public void SetAllOptions(DataTable table)
        {
            string[] optionsList = table.Columns.Cast<DataColumn>().Select(column => column.ColumnName).ToArray();
            foreach (string option in optionsList)
            {
                AddOption(option);
            }
        }

        private void txtFilterBox_TextChanged(object sender, EventArgs e)
        {
            if (_dataGridView != null && _originalTable != null)
            {
                string filterExpression = "";
                if (!string.IsNullOrWhiteSpace(txtFilterBox.Text))
                {
                    filterExpression = $"[{comboFilterBox.Text}] Like '%{txtFilterBox.Text}%'";
                }

                DataView dataView = new DataView(_originalTable, filterExpression, null, DataViewRowState.CurrentRows);
                _dataGridView.DataSource = dataView; // Update DataGridView's DataSource with the filtered DataView
                FilterFunction?.Invoke(dataView); // Invoke the filter function with the DataView
            }
        }

        private void comboFilterBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboFilterBox.SelectedIndex == 0) {
                txtFilterBox.Enabled = false;
                txtFilterBox.Text = "";
            }
            else
            {
                txtFilterBox.Enabled = true;

            }

        }
    }
}