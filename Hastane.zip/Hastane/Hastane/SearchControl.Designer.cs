﻿namespace Hastane
{
    partial class SearchControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboFilterBox = new System.Windows.Forms.ComboBox();
            this.txtFilterBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboFilterBox
            // 
            this.comboFilterBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFilterBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.comboFilterBox.FormattingEnabled = true;
            this.comboFilterBox.Items.AddRange(new object[] {
            "Hic"});
            this.comboFilterBox.Location = new System.Drawing.Point(107, 9);
            this.comboFilterBox.Name = "comboFilterBox";
            this.comboFilterBox.Size = new System.Drawing.Size(222, 30);
            this.comboFilterBox.TabIndex = 13;
            this.comboFilterBox.SelectedIndexChanged += new System.EventHandler(this.comboFilterBox_SelectedIndexChanged);
            // 
            // txtFilterBox
            // 
            this.txtFilterBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtFilterBox.Location = new System.Drawing.Point(335, 11);
            this.txtFilterBox.Name = "txtFilterBox";
            this.txtFilterBox.Size = new System.Drawing.Size(245, 28);
            this.txtFilterBox.TabIndex = 12;
            this.txtFilterBox.TextChanged += new System.EventHandler(this.txtFilterBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(7, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 22);
            this.label1.TabIndex = 14;
            this.label1.Text = "ile filtrele";
            // 
            // SearchControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboFilterBox);
            this.Controls.Add(this.txtFilterBox);
            this.Name = "SearchControl";
            this.Size = new System.Drawing.Size(614, 48);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboFilterBox;
        private System.Windows.Forms.TextBox txtFilterBox;
        private System.Windows.Forms.Label label1;
    }
}
