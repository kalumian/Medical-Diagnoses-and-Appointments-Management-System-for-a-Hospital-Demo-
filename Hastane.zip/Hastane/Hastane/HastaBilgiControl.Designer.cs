﻿namespace Hastane
{
    partial class HastaBilgiControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAdres = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtTelefon = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtKan = new System.Windows.Forms.Label();
            this.txtMeslek = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtEgitim = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtMedeni = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCinsiyet = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTarih = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAdi = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTC = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAdres
            // 
            this.txtAdres.AutoSize = true;
            this.txtAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtAdres.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtAdres.Location = new System.Drawing.Point(251, 299);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(34, 25);
            this.txtAdres.TabIndex = 99;
            this.txtAdres.Text = "__";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(21, 299);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 25);
            this.label26.TabIndex = 97;
            this.label26.Text = "Adres:";
            // 
            // txtTelefon
            // 
            this.txtTelefon.AutoSize = true;
            this.txtTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtTelefon.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTelefon.Location = new System.Drawing.Point(695, 143);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(34, 25);
            this.txtTelefon.TabIndex = 96;
            this.txtTelefon.Text = "__";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(465, 143);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 25);
            this.label24.TabIndex = 94;
            this.label24.Text = "Telefon No:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(443, 32);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 25);
            this.label23.TabIndex = 92;
            this.label23.Text = "Kan Grubu:";
            // 
            // txtKan
            // 
            this.txtKan.AutoSize = true;
            this.txtKan.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtKan.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtKan.Location = new System.Drawing.Point(684, -1);
            this.txtKan.Name = "txtKan";
            this.txtKan.Size = new System.Drawing.Size(127, 91);
            this.txtKan.TabIndex = 91;
            this.txtKan.Text = "__";
            // 
            // txtMeslek
            // 
            this.txtMeslek.AutoSize = true;
            this.txtMeslek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtMeslek.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMeslek.Location = new System.Drawing.Point(695, 246);
            this.txtMeslek.Name = "txtMeslek";
            this.txtMeslek.Size = new System.Drawing.Size(34, 25);
            this.txtMeslek.TabIndex = 90;
            this.txtMeslek.Text = "__";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label18.Location = new System.Drawing.Point(465, 246);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 25);
            this.label18.TabIndex = 88;
            this.label18.Text = "Meslek:";
            // 
            // txtEgitim
            // 
            this.txtEgitim.AutoSize = true;
            this.txtEgitim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtEgitim.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEgitim.Location = new System.Drawing.Point(695, 196);
            this.txtEgitim.Name = "txtEgitim";
            this.txtEgitim.Size = new System.Drawing.Size(34, 25);
            this.txtEgitim.TabIndex = 87;
            this.txtEgitim.Text = "__";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(465, 196);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(134, 25);
            this.label20.TabIndex = 85;
            this.label20.Text = "Egitim Durum:";
            // 
            // txtMedeni
            // 
            this.txtMedeni.AutoSize = true;
            this.txtMedeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtMedeni.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedeni.Location = new System.Drawing.Point(251, 246);
            this.txtMedeni.Name = "txtMedeni";
            this.txtMedeni.Size = new System.Drawing.Size(34, 25);
            this.txtMedeni.TabIndex = 84;
            this.txtMedeni.Text = "__";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(21, 246);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(146, 25);
            this.label16.TabIndex = 82;
            this.label16.Text = "Medeni Durum:";
            // 
            // txtCinsiyet
            // 
            this.txtCinsiyet.AutoSize = true;
            this.txtCinsiyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCinsiyet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCinsiyet.Location = new System.Drawing.Point(251, 196);
            this.txtCinsiyet.Name = "txtCinsiyet";
            this.txtCinsiyet.Size = new System.Drawing.Size(34, 25);
            this.txtCinsiyet.TabIndex = 81;
            this.txtCinsiyet.Text = "__";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(21, 196);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 25);
            this.label14.TabIndex = 79;
            this.label14.Text = "Cinsiyet:";
            // 
            // txtTarih
            // 
            this.txtTarih.AutoSize = true;
            this.txtTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtTarih.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTarih.Location = new System.Drawing.Point(251, 143);
            this.txtTarih.Name = "txtTarih";
            this.txtTarih.Size = new System.Drawing.Size(34, 25);
            this.txtTarih.TabIndex = 78;
            this.txtTarih.Text = "__";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(21, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 25);
            this.label12.TabIndex = 76;
            this.label12.Text = "Dogum Tarih:";
            // 
            // txtAdi
            // 
            this.txtAdi.AutoSize = true;
            this.txtAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtAdi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtAdi.Location = new System.Drawing.Point(251, 88);
            this.txtAdi.Name = "txtAdi";
            this.txtAdi.Size = new System.Drawing.Size(34, 25);
            this.txtAdi.TabIndex = 75;
            this.txtAdi.Text = "__";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(20, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 25);
            this.label10.TabIndex = 73;
            this.label10.Text = "Hasta Tum Adi:";
            // 
            // txtTC
            // 
            this.txtTC.AutoSize = true;
            this.txtTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtTC.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTC.Location = new System.Drawing.Point(251, 32);
            this.txtTC.Name = "txtTC";
            this.txtTC.Size = new System.Drawing.Size(34, 25);
            this.txtTC.TabIndex = 72;
            this.txtTC.Text = "__";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(21, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 25);
            this.label7.TabIndex = 70;
            this.label7.Text = "Hasta TC:";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::Hastane.Properties.Resources.icons8_address_32__1_;
            this.pictureBox15.Location = new System.Drawing.Point(177, 293);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(36, 33);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 98;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::Hastane.Properties.Resources.icons8_phone_32__1_;
            this.pictureBox14.Location = new System.Drawing.Point(621, 137);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(36, 33);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 95;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Hastane.Properties.Resources.icons8_blood_32;
            this.pictureBox13.Location = new System.Drawing.Point(562, 29);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(36, 33);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 93;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Hastane.Properties.Resources.icons8_job_32;
            this.pictureBox11.Location = new System.Drawing.Point(621, 240);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(36, 33);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 89;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Hastane.Properties.Resources.icons8_education_32;
            this.pictureBox12.Location = new System.Drawing.Point(621, 190);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(36, 33);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 86;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Hastane.Properties.Resources.icons8_married_32;
            this.pictureBox10.Location = new System.Drawing.Point(177, 240);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(36, 33);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 83;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Hastane.Properties.Resources.icons8_sex_30;
            this.pictureBox9.Location = new System.Drawing.Point(177, 190);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(36, 33);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 80;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Hastane.Properties.Resources.icons8_birthdate_32;
            this.pictureBox8.Location = new System.Drawing.Point(177, 137);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(36, 33);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 77;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Hastane.Properties.Resources.icons8_user_32__1_;
            this.pictureBox7.Location = new System.Drawing.Point(176, 82);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(36, 33);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 74;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Hastane.Properties.Resources.icons8_id_30;
            this.pictureBox6.Location = new System.Drawing.Point(177, 26);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(36, 33);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 71;
            this.pictureBox6.TabStop = false;
            // 
            // HastaBilgiControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtAdres);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtTelefon);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtKan);
            this.Controls.Add(this.txtMeslek);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtEgitim);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtMedeni);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCinsiyet);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtTarih);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtAdi);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtTC);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label7);
            this.Name = "HastaBilgiControl";
            this.Size = new System.Drawing.Size(808, 347);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtAdres;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label txtTelefon;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label txtKan;
        private System.Windows.Forms.Label txtMeslek;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label txtEgitim;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label txtMedeni;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label txtCinsiyet;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label txtTarih;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label txtAdi;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label txtTC;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label7;
    }
}
