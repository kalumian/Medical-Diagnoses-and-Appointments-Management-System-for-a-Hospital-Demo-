﻿namespace Hastane
{
    partial class Muayeneler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Muayeneler));
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewWithSearchControl1 = new Hastane.DataGridViewWithSearchControl();
            this.Strip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.bilgileriGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextStrip = new System.Windows.Forms.ToolStripSeparator();
            this.yeniMuayeneEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gunceleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incelemeSonucuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Strip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(387, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 46);
            this.label1.TabIndex = 1;
            this.label1.Text = "Muayeneler";
            // 
            // dataGridViewWithSearchControl1
            // 
            this.dataGridViewWithSearchControl1.EnableAddButton = true;
            this.dataGridViewWithSearchControl1.Location = new System.Drawing.Point(12, 200);
            this.dataGridViewWithSearchControl1.Name = "dataGridViewWithSearchControl1";
            this.dataGridViewWithSearchControl1.Size = new System.Drawing.Size(951, 502);
            this.dataGridViewWithSearchControl1.TabIndex = 2;
            this.dataGridViewWithSearchControl1.OnObjectAdded += new System.Action<object>(this.dataGridViewWithSearchControl1_OnObjectAdded);
            // 
            // Strip
            // 
            this.Strip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Strip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bilgileriGörüntüleToolStripMenuItem,
            this.contextStrip,
            this.yeniMuayeneEkleToolStripMenuItem,
            this.gunceleToolStripMenuItem,
            this.dToolStripMenuItem,
            this.incelemeSonucuToolStripMenuItem});
            this.Strip.Name = "contextMenuStrip1";
            this.Strip.Size = new System.Drawing.Size(205, 140);
            // 
            // bilgileriGörüntüleToolStripMenuItem
            // 
            this.bilgileriGörüntüleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_papers_322;
            this.bilgileriGörüntüleToolStripMenuItem.Name = "bilgileriGörüntüleToolStripMenuItem";
            this.bilgileriGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.bilgileriGörüntüleToolStripMenuItem.Text = "Bilgileri görüntüle";
            this.bilgileriGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bilgileriGörüntüleToolStripMenuItem_Click);
            // 
            // contextStrip
            // 
            this.contextStrip.Name = "contextStrip";
            this.contextStrip.Size = new System.Drawing.Size(201, 6);
            // 
            // yeniMuayeneEkleToolStripMenuItem
            // 
            this.yeniMuayeneEkleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_add_32__1_3;
            this.yeniMuayeneEkleToolStripMenuItem.Name = "yeniMuayeneEkleToolStripMenuItem";
            this.yeniMuayeneEkleToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.yeniMuayeneEkleToolStripMenuItem.Text = "Yeni Muayene Ekle";
            this.yeniMuayeneEkleToolStripMenuItem.Click += new System.EventHandler(this.yeniMuayeneEkleToolStripMenuItem_Click);
            // 
            // gunceleToolStripMenuItem
            // 
            this.gunceleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_edit_32__1_1;
            this.gunceleToolStripMenuItem.Name = "gunceleToolStripMenuItem";
            this.gunceleToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.gunceleToolStripMenuItem.Text = "Guncelle";
            this.gunceleToolStripMenuItem.Click += new System.EventHandler(this.gunceleToolStripMenuItem_Click);
            // 
            // dToolStripMenuItem
            // 
            this.dToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_delete_322;
            this.dToolStripMenuItem.Name = "dToolStripMenuItem";
            this.dToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.dToolStripMenuItem.Text = "Sil";
            this.dToolStripMenuItem.Click += new System.EventHandler(this.dToolStripMenuItem_Click);
            // 
            // incelemeSonucuToolStripMenuItem
            // 
            this.incelemeSonucuToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_result_32;
            this.incelemeSonucuToolStripMenuItem.Name = "incelemeSonucuToolStripMenuItem";
            this.incelemeSonucuToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.incelemeSonucuToolStripMenuItem.Text = "Inceleme sonucu";
            this.incelemeSonucuToolStripMenuItem.Click += new System.EventHandler(this.incelemeSonucuToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hastane.Properties.Resources.icons8_time_96__1_2;
            this.pictureBox1.Location = new System.Drawing.Point(438, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 108);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Muayeneler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 607);
            this.Controls.Add(this.dataGridViewWithSearchControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Muayeneler";
            this.Text = "Muayeneler";
            this.Strip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private DataGridViewWithSearchControl dataGridViewWithSearchControl1;
        private System.Windows.Forms.ContextMenuStrip Strip;
        private System.Windows.Forms.ToolStripMenuItem dToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bilgileriGörüntüleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator contextStrip;
        private System.Windows.Forms.ToolStripMenuItem gunceleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incelemeSonucuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniMuayeneEkleToolStripMenuItem;
    }
}