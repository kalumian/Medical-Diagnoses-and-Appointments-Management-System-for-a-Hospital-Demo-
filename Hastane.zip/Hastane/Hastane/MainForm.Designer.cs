﻿namespace Hastane
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.muayenelerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hastalarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doktorlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polikliniklerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hakkımızdaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.muayenelerToolStripMenuItem,
            this.hastalarToolStripMenuItem,
            this.doktorlarToolStripMenuItem,
            this.polikliniklerToolStripMenuItem,
            this.hakkımızdaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1053, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // muayenelerToolStripMenuItem
            // 
            this.muayenelerToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.muayenelerToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_time_96__1_1;
            this.muayenelerToolStripMenuItem.Name = "muayenelerToolStripMenuItem";
            this.muayenelerToolStripMenuItem.Size = new System.Drawing.Size(137, 29);
            this.muayenelerToolStripMenuItem.Text = "Muayeneler";
            this.muayenelerToolStripMenuItem.Click += new System.EventHandler(this.muayenelerToolStripMenuItem_Click);
            // 
            // hastalarToolStripMenuItem
            // 
            this.hastalarToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.hastalarToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_ill_96__1_;
            this.hastalarToolStripMenuItem.Name = "hastalarToolStripMenuItem";
            this.hastalarToolStripMenuItem.Size = new System.Drawing.Size(110, 29);
            this.hastalarToolStripMenuItem.Text = "Hastalar";
            this.hastalarToolStripMenuItem.Click += new System.EventHandler(this.hastalarToolStripMenuItem_Click);
            // 
            // doktorlarToolStripMenuItem
            // 
            this.doktorlarToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.doktorlarToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_doctor_96__1_;
            this.doktorlarToolStripMenuItem.Name = "doktorlarToolStripMenuItem";
            this.doktorlarToolStripMenuItem.Size = new System.Drawing.Size(121, 29);
            this.doktorlarToolStripMenuItem.Text = "Doktorlar";
            this.doktorlarToolStripMenuItem.Click += new System.EventHandler(this.doktorlarToolStripMenuItem_Click);
            // 
            // polikliniklerToolStripMenuItem
            // 
            this.polikliniklerToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.polikliniklerToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_clinic_96__1_;
            this.polikliniklerToolStripMenuItem.Name = "polikliniklerToolStripMenuItem";
            this.polikliniklerToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.polikliniklerToolStripMenuItem.Text = "Poliklinikler";
            this.polikliniklerToolStripMenuItem.Click += new System.EventHandler(this.polikliniklerToolStripMenuItem_Click);
            // 
            // hakkımızdaToolStripMenuItem
            // 
            this.hakkımızdaToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.hakkımızdaToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_team_96;
            this.hakkımızdaToolStripMenuItem.Name = "hakkımızdaToolStripMenuItem";
            this.hakkımızdaToolStripMenuItem.Size = new System.Drawing.Size(138, 29);
            this.hakkımızdaToolStripMenuItem.Text = "Hakkımızda";
            this.hakkımızdaToolStripMenuItem.Click += new System.EventHandler(this.hakkımızdaToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Hastane.Properties.Resources.Beyaz_Hastane_Simgesi_Medikal_Logo__4_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1053, 375);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hastane";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem muayenelerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hastalarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doktorlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polikliniklerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hakkımızdaToolStripMenuItem;
    }
}

