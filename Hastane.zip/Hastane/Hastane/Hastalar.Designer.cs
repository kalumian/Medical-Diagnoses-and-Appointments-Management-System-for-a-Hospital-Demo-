﻿namespace Hastane
{
    partial class Hastalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hastalar));
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridViewWithSearchControl1 = new Hastane.DataGridViewWithSearchControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bilgileriGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniHastaEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.silToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(403, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 46);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hastalar";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bilgileriGörüntüleToolStripMenuItem,
            this.toolStripMenuItem1,
            this.yeniHastaEkleToolStripMenuItem,
            this.silToolStripMenuItem,
            this.guncelleToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(202, 114);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(198, 6);
            // 
            // dataGridViewWithSearchControl1
            // 
            this.dataGridViewWithSearchControl1.EnableAddButton = true;
            this.dataGridViewWithSearchControl1.Location = new System.Drawing.Point(10, 193);
            this.dataGridViewWithSearchControl1.Name = "dataGridViewWithSearchControl1";
            this.dataGridViewWithSearchControl1.Size = new System.Drawing.Size(951, 407);
            this.dataGridViewWithSearchControl1.TabIndex = 5;
            this.dataGridViewWithSearchControl1.OnObjectAdded += new System.Action<object>(this.dataGridViewWithSearchControl1_OnObjectAdded);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hastane.Properties.Resources.icons8_ill_96__1_2;
            this.pictureBox1.Location = new System.Drawing.Point(429, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 108);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // bilgileriGörüntüleToolStripMenuItem
            // 
            this.bilgileriGörüntüleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_papers_321;
            this.bilgileriGörüntüleToolStripMenuItem.Name = "bilgileriGörüntüleToolStripMenuItem";
            this.bilgileriGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.bilgileriGörüntüleToolStripMenuItem.Text = "Bilgileri görüntüle";
            this.bilgileriGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bilgileriGörüntüleToolStripMenuItem_Click);
            // 
            // yeniHastaEkleToolStripMenuItem
            // 
            this.yeniHastaEkleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_add_32__1_2;
            this.yeniHastaEkleToolStripMenuItem.Name = "yeniHastaEkleToolStripMenuItem";
            this.yeniHastaEkleToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.yeniHastaEkleToolStripMenuItem.Text = "Yeni Hasta Ekle";
            this.yeniHastaEkleToolStripMenuItem.Click += new System.EventHandler(this.yeniHastaEkleToolStripMenuItem_Click);
            // 
            // silToolStripMenuItem
            // 
            this.silToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_delete_321;
            this.silToolStripMenuItem.Name = "silToolStripMenuItem";
            this.silToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.silToolStripMenuItem.Text = "Sil";
            this.silToolStripMenuItem.Click += new System.EventHandler(this.silToolStripMenuItem_Click);
            // 
            // guncelleToolStripMenuItem
            // 
            this.guncelleToolStripMenuItem.Image = global::Hastane.Properties.Resources.icons8_edit_32__1_;
            this.guncelleToolStripMenuItem.Name = "guncelleToolStripMenuItem";
            this.guncelleToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.guncelleToolStripMenuItem.Text = "Guncelle";
            this.guncelleToolStripMenuItem.Click += new System.EventHandler(this.guncelleToolStripMenuItem_Click);
            // 
            // Hastalar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 597);
            this.Controls.Add(this.dataGridViewWithSearchControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Hastalar";
            this.Text = "Hastalar";
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridViewWithSearchControl dataGridViewWithSearchControl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bilgileriGörüntüleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniHastaEkleToolStripMenuItem;
    }
}