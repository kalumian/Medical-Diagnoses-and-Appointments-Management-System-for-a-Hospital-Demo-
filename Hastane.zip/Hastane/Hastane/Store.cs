﻿using Hastane.Business_Layer;
using Hastane.Database_Access_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    static public class Store
    {
        // --------------------------------------
       static private DataTable _Meslekler { get; set; }
       static public DataTable Meslekler { get { return _Meslekler; } }
        // --------------------------------------

       static private DataTable _Egitim_Durumlari { get; set; }
       static public DataTable Egitim_Durumlari { get { return _Egitim_Durumlari; } }
        // --------------------------------------

       static private DataTable _Kan_Grublari { get; set; }
       static public DataTable Kan_Grublari { get { return _Kan_Grublari; } }
        // --------------------------------------

       static private DataTable _Medeni_durumlari { get; set; }
       static public DataTable Medeni_durumlari { get { return _Medeni_durumlari; } }
        // --------------------------------------

       static private DataTable _Cinsiyetler { get; set; }
       static public DataTable Cinsiyetler { get { return _Cinsiyetler; } }
        // --------------------------------------

        static public void InitializeStore()
        {
            _Cinsiyetler = Main.getCinsiyetler();
            _Medeni_durumlari = Main.getMedeni_durumlari();
            _Kan_Grublari = Main.getKan_Grublari();
            _Egitim_Durumlari = Main.getEgitim_Durumlari();
            _Meslekler = Main.getMeslekler();
        }
        static public void setDataIntoComboBox(ComboBox ComboBox, DataTable datatable, string columnName, string columnID)
        {
            foreach (DataRow Row in datatable.Rows)
            {
                string name = Row[columnName].ToString();
                string id = Row[columnID].ToString();
                ComboBox.Items.Add(Tuple.Create(name,id));
            }
        }
        
        static public void MessageError(string Messsage) { 
            MessageBox.Show(Messsage,"Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        static public void MessageCorrect(string Messsage)
        {
            MessageBox.Show(Messsage, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
