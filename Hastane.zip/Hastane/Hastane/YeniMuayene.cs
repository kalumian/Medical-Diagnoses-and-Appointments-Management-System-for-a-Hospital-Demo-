﻿using Hastane.Business_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hastane
{
    public partial class YeniMuayene : Form
    {
        private bool Edit_Mod { get; set; } = false;
        public YeniMuayene()
        {
            InitializeComponent();
            comboDoktorBox.Enabled = false;
            hastaBilgiControl.Enabled = false;
            Store.setDataIntoComboBox(comboPoliklinikBox, clsPoliklinik.GetAllPoliklinikler(), "Poliklinik Adi", "Poliklinik ID");
        }
        public YeniMuayene(string hasta_Tc, string doktor_Tc, DateTime muayene_tarihi, string Poliklinik_adi, int MuayeneID, bool Edit = false)
        {
            
            InitializeComponent();
            Store.setDataIntoComboBox(comboPoliklinikBox, clsPoliklinik.GetAllPoliklinikler(), "Poliklinik Adi", "Poliklinik ID");
            txtHastaTcBox.Text = hasta_Tc;
            MuayeneTarihi.Value = muayene_tarihi;
            setDoktorVePoliklinik(doktor_Tc, Poliklinik_adi);
            this.Edit_Mod = Edit;
            title.Text = "Muayene Bilgileri düzenle";
            txt_muayene_id.Text = MuayeneID.ToString();
            if (!Edit)
            {
                title.Text = "Muayene bilgileri";
                comboDoktorBox.Enabled = false;
                comboPoliklinikBox.Enabled = false;
                txtHastaTcBox.Enabled = false;
                btnAdd.Enabled = false;
                btnSearch.Enabled = false;
                MuayeneTarihi.Enabled = false;
                formControl1.BtnSaveEnable = false;
                hastaBilgiControl.Enabled = false;
            }
            setHasta();

        }
        private bool _isHastExist { get; set; } = false;
        private void setDoktorVePoliklinik(string doktor_Tc, string Poliklinik_adi)
        {

            foreach (var item in comboPoliklinikBox.Items)
            {
                if (item is Tuple<string, string> row && row.Item1 == Poliklinik_adi)
                {
                    comboPoliklinikBox.SelectedItem = row;
                    break;
                }
            }
            foreach (var item in comboDoktorBox.Items)
            {
                if (item is Tuple<string, string> row && row.Item2 == doktor_Tc)
                {
                    comboDoktorBox.SelectedItem = row;
                    break;
                }
            }

        }
        private void setHasta()
        {
            if (hastaBilgiControl.setHasta(txtHastaTcBox.Text))
            {
                _isHastExist = true;
                hastaBilgiControl.Enabled = true;
            }
            else
            {
                Store.MessageError("Hasta mevcut degil");
                _isHastExist = false;
                hastaBilgiControl.Enabled = false;
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            setHasta();
        }

        private void YeniMuayene_Load(object sender, EventArgs e)
        {

        }

        private void comboPoliklinikBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboPoliklinikBox.SelectedIndex > 0)
            {
                Store.setDataIntoComboBox(comboDoktorBox, clsDoktor.GetAllDoktorByPoliklinik(comboPoliklinikBox.SelectedIndex), "Doktor Tum Adi" , "doktor_Tc");
                comboDoktorBox.Enabled =true;
            }
            else
            {
                comboDoktorBox.Enabled = false;
            }
            comboDoktorBox.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void resetValues() {
            comboPoliklinikBox.SelectedIndex = 0;
            _isHastExist = false;
            txtHastaTcBox.Text = "";
            hastaBilgiControl.Enabled = false;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            new YeniHasta().ShowDialog();
        }

        private void formControl1_OnBtnSaveClick(object obj)
        {
            if (
               comboDoktorBox.SelectedIndex != 0 &&
               comboPoliklinikBox.SelectedIndex != 0 &&
                          _isHastExist &&
            comboDoktorBox.SelectedItem is Tuple<string, string> selectedDoktorItem
               )
            {

                if (!Edit_Mod)
                {
                    int Muayene_Id = clsMuayene.AddMuayene(txtHastaTcBox.Text, selectedDoktorItem.Item2, MuayeneTarihi.Value);
                    if (Muayene_Id != -1)
                    {
                        txt_muayene_id.Text = Muayene_Id.ToString();
                        resetValues();
                        MessageBox.Show("Muayene başarıyla eklendi");
                    }
                    else
                    {
                        Store.MessageError("Sistimde bir hata oluştu");
                    }
                }
                else
                {
                    if (clsMuayene.UpdateMuayene(txtHastaTcBox.Text, selectedDoktorItem.Item2, MuayeneTarihi.Value, int.Parse(txt_muayene_id.Text)))
                    {
                        MessageBox.Show("Muayene başarıyla değiştirildi");
                    }
                    else
                    {
                        Store.MessageError("Sistimde bir hata oluştu");

                    }
                }
            }
            else
            {
                Store.MessageError("Bir hata oluştu. Girişi doğrulayın.");
            }
        }

        private void formControl1_OnBtnCloseClick(object obj)
        {
            this.Close();
        }
    }
}
