﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hastane.Business_Layer;

namespace Hastane
{
    public partial class Muayeneler : Form
    {
        public Muayeneler()
        {
            InitializeComponent();
            dataGridViewWithSearchControl1.InitializeDataGridViewComponent(clsMuayene.GetAllMuayene());
            dataGridViewWithSearchControl1.Strip = Strip;
        }
        private void _LoadMuayeneData()
        {
            dataGridViewWithSearchControl1.InitializeDataGridViewComponent(clsMuayene.GetAllMuayene());

        }
        private void dataGridViewWithSearchControl1_OnObjectAdded(object obj)
        {
            new YeniMuayene().ShowDialog();
            _LoadMuayeneData();
        }

        private void getMuayeneDataFromSelectRow(out string hastaTc, out string doktorTc, out string poliklinikAdi, out DateTime muayeneTarihi, out int muayene_Id)
        {
            hastaTc = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Hasta TC"].Value.ToString();
            doktorTc = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Doktor TC"].Value.ToString();
            poliklinikAdi = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Poliklinik"].Value.ToString();
            muayene_Id = Convert.ToInt32(dataGridViewWithSearchControl1.SelectedRows[0].Cells["Muayene ID"].Value);
            muayeneTarihi = Convert.ToDateTime(dataGridViewWithSearchControl1.SelectedRows[0].Cells["Muayene tarihi"].Value);

        }
    
        private void bilgileriGörüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewWithSearchControl1.SelectedRows.Count > 0) {
                string hastaTc, doktorTc, poliklinikAdi;
                DateTime muayeneTarihi;
                int muayene_Id;
                getMuayeneDataFromSelectRow(out hastaTc, out doktorTc, out poliklinikAdi, out muayeneTarihi, out muayene_Id);
                YeniMuayene yeniMuayeneForm = new YeniMuayene(hastaTc, doktorTc, muayeneTarihi, poliklinikAdi, muayene_Id);
                yeniMuayeneForm.ShowDialog();
            }   
        }

        private void gunceleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string hastaTc, doktorTc, poliklinikAdi;
            DateTime muayeneTarihi;
            int muayene_Id;
            getMuayeneDataFromSelectRow(out hastaTc, out doktorTc, out poliklinikAdi, out muayeneTarihi, out muayene_Id);
            YeniMuayene yeniMuayeneForm = new YeniMuayene(hastaTc, doktorTc, muayeneTarihi, poliklinikAdi, muayene_Id, true);
            yeniMuayeneForm.ShowDialog();
            _LoadMuayeneData();
        }

        private void incelemeSonucuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string hastaTc, doktorTc, poliklinikAdi;
            DateTime muayeneTarihi;
            int muayene_Id;
            string doktorAdi = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Doktor"].Value.ToString();
            string hastaAdi = dataGridViewWithSearchControl1.SelectedRows[0].Cells["Hasta Tum Adi"].Value.ToString();
            getMuayeneDataFromSelectRow(out hastaTc, out doktorTc, out poliklinikAdi, out muayeneTarihi, out muayene_Id);
            new MuayeneSonucu(muayene_Id, doktorAdi, hastaTc, hastaAdi, poliklinikAdi, muayeneTarihi).ShowDialog();
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string hastaTc, doktorTc, poliklinikAdi;
            DateTime muayeneTarihi;
            int muayene_Id;
            getMuayeneDataFromSelectRow(out hastaTc, out doktorTc, out poliklinikAdi, out muayeneTarihi, out muayene_Id);
            if (clsMuayene.DeleteMuayene(muayene_Id))
            {
                MessageBox.Show("başarıyla silindi", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Store.MessageError("Hata oluştu, silme işlemi gerçekleşmedi");
            }
            _LoadMuayeneData();
        }

        private void yeniMuayeneEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new YeniMuayene().ShowDialog();
            _LoadMuayeneData();
        }
    }
}
