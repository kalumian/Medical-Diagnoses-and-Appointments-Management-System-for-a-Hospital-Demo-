﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hastane.Business_Layer;
namespace Hastane
{
    public partial class HastaBilgiControl : UserControl
    {
        public HastaBilgiControl()
        {
            InitializeComponent();
        }
        public bool setHasta(string hasta_Tc)
        {
            clsHasta hasta = clsHasta.Find(hasta_Tc);
            if (hasta != null)
            {
                txtTC.Text = hasta.hasta_Tc;
                txtAdi.Text = hasta.hasta_Adi + hasta.hasta_Soyadi;
                txtCinsiyet.Text = Store.Cinsiyetler.Rows[hasta.cinsiyet_Id - 1][1].ToString();
                txtKan.Text = Store.Kan_Grublari.Rows[hasta.kan_grubu_Id - 1][1].ToString();
                if (txtKan.Text[1] == '+')
                {
                    txtKan.ForeColor = Color.Green;
                }
                else
                {
                    txtKan.ForeColor = Color.Red;
                }
                txtEgitim.Text = Store.Egitim_Durumlari.Rows[hasta.egitim_durumu_Id][1].ToString();
                txtMedeni.Text = Store.Medeni_durumlari.Rows[hasta.medeni_durum_Id][1].ToString();
                txtMeslek.Text = Store.Meslekler.Rows[hasta.meslek_Id][1].ToString();
                txtTarih.Text = hasta.dogum_tarihi.ToShortDateString();
                txtTelefon.Text = hasta.telefon_no;
                txtAdres.Text = hasta.adres;
                return true;
            }
            else
            {
                return false;
            }
          
        }
    }
}
