﻿namespace Hastane
{
    partial class YeniMuayene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YeniMuayene));
            this.title = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboPoliklinikBox = new System.Windows.Forms.ComboBox();
            this.comboDoktorBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.MuayeneTarihi = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtHastaTcBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_muayene_id = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.formControl1 = new Hastane.formControl();
            this.hastaBilgiControl = new Hastane.HastaBilgiControl();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.title.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.title.Location = new System.Drawing.Point(125, 47);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(273, 46);
            this.title.TabIndex = 3;
            this.title.Text = "Yeni Muayene";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(12, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Poliklinik:";
            // 
            // comboPoliklinikBox
            // 
            this.comboPoliklinikBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPoliklinikBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.comboPoliklinikBox.FormattingEnabled = true;
            this.comboPoliklinikBox.Items.AddRange(new object[] {
            "Poliklinik Sec"});
            this.comboPoliklinikBox.Location = new System.Drawing.Point(200, 144);
            this.comboPoliklinikBox.Name = "comboPoliklinikBox";
            this.comboPoliklinikBox.Size = new System.Drawing.Size(253, 30);
            this.comboPoliklinikBox.TabIndex = 17;
            this.comboPoliklinikBox.SelectedIndexChanged += new System.EventHandler(this.comboPoliklinikBox_SelectedIndexChanged);
            // 
            // comboDoktorBox
            // 
            this.comboDoktorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboDoktorBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.comboDoktorBox.FormattingEnabled = true;
            this.comboDoktorBox.Items.AddRange(new object[] {
            "Doktor Sec"});
            this.comboDoktorBox.Location = new System.Drawing.Point(200, 194);
            this.comboDoktorBox.Name = "comboDoktorBox";
            this.comboDoktorBox.Size = new System.Drawing.Size(253, 30);
            this.comboDoktorBox.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(12, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 25);
            this.label4.TabIndex = 19;
            this.label4.Text = "Doktor:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(13, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 25);
            this.label5.TabIndex = 22;
            this.label5.Text = "Hasta:";
            // 
            // MuayeneTarihi
            // 
            this.MuayeneTarihi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MuayeneTarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.MuayeneTarihi.Location = new System.Drawing.Point(692, 146);
            this.MuayeneTarihi.Name = "MuayeneTarihi";
            this.MuayeneTarihi.Size = new System.Drawing.Size(253, 27);
            this.MuayeneTarihi.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(487, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 25);
            this.label6.TabIndex = 26;
            this.label6.Text = "Muayene Tarihi";
            // 
            // txtHastaTcBox
            // 
            this.txtHastaTcBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHastaTcBox.Location = new System.Drawing.Point(201, 250);
            this.txtHastaTcBox.MaxLength = 11;
            this.txtHastaTcBox.Name = "txtHastaTcBox";
            this.txtHastaTcBox.Size = new System.Drawing.Size(253, 28);
            this.txtHastaTcBox.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(739, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 25);
            this.label1.TabIndex = 36;
            this.label1.Text = "Muayene ID";
            // 
            // txt_muayene_id
            // 
            this.txt_muayene_id.AutoSize = true;
            this.txt_muayene_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_muayene_id.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txt_muayene_id.Location = new System.Drawing.Point(863, 29);
            this.txt_muayene_id.Name = "txt_muayene_id";
            this.txt_muayene_id.Size = new System.Drawing.Size(34, 25);
            this.txt_muayene_id.TabIndex = 37;
            this.txt_muayene_id.Text = "__";
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::Hastane.Properties.Resources.icons8_add_32__1_1;
            this.btnAdd.Location = new System.Drawing.Point(530, 242);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(54, 48);
            this.btnAdd.TabIndex = 32;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::Hastane.Properties.Resources.icons8_search_color_32;
            this.btnSearch.Location = new System.Drawing.Point(470, 242);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 48);
            this.btnSearch.TabIndex = 31;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Hastane.Properties.Resources.icons8_date_321;
            this.pictureBox5.Location = new System.Drawing.Point(642, 142);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(36, 33);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 28;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Hastane.Properties.Resources.icons8_ill_96__1_3;
            this.pictureBox4.Location = new System.Drawing.Point(151, 246);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(36, 33);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Hastane.Properties.Resources.icons8_doctor_96__1_2;
            this.pictureBox3.Location = new System.Drawing.Point(150, 192);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 33);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Hastane.Properties.Resources.icons8_clinic_96__1_2;
            this.pictureBox2.Location = new System.Drawing.Point(150, 142);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(36, 33);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hastane.Properties.Resources.icons8_time_96__1_2;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 108);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // formControl1
            // 
            this.formControl1.BtnSaveEnable = true;
            this.formControl1.Location = new System.Drawing.Point(317, 662);
            this.formControl1.Name = "formControl1";
            this.formControl1.Size = new System.Drawing.Size(338, 58);
            this.formControl1.TabIndex = 38;
            this.formControl1.OnBtnCloseClick += new System.Action<object>(this.formControl1_OnBtnCloseClick);
            this.formControl1.OnBtnSaveClick += new System.Action<object>(this.formControl1_OnBtnSaveClick);
            // 
            // hastaBilgiControl
            // 
            this.hastaBilgiControl.Location = new System.Drawing.Point(18, 296);
            this.hastaBilgiControl.Name = "hastaBilgiControl";
            this.hastaBilgiControl.Size = new System.Drawing.Size(891, 337);
            this.hastaBilgiControl.TabIndex = 33;
            // 
            // YeniMuayene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 732);
            this.Controls.Add(this.formControl1);
            this.Controls.Add(this.txt_muayene_id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hastaBilgiControl);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtHastaTcBox);
            this.Controls.Add(this.MuayeneTarihi);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.comboDoktorBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboPoliklinikBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.title);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "YeniMuayene";
            this.Text = "YeniMuayene";
            this.Load += new System.EventHandler(this.YeniMuayene_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboPoliklinikBox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ComboBox comboDoktorBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker MuayeneTarihi;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtHastaTcBox;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnAdd;
        private HastaBilgiControl hastaBilgiControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txt_muayene_id;
        private formControl formControl1;
    }
}