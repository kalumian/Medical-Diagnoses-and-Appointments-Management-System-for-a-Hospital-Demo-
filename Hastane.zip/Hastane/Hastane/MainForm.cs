﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            Store.InitializeStore();
        }
        private void muayenelerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Muayeneler MuayenekerForm = new Muayeneler();
            MuayenekerForm.Show();
        }

        private void hastalarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Hastalar().Show();
        }

        private void doktorlarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Dokrorlar().Show();
        }

        private void polikliniklerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Poliklinikler().Show();
        }

        private void hakkımızdaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Hakkimizda().Show();
        }
    }
}
