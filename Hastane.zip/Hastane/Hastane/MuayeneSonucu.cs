﻿using Hastane.Business_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class MuayeneSonucu : Form
    {
        public MuayeneSonucu(int muayene_Id, string DoktorAdi, string HastaTc, string HastaAdi, string Poliklinik, DateTime muayeneTarihi)
        {
            InitializeComponent();
            string Recete = "", Tani = "";
            txtMuayeneID.Text = muayene_Id.ToString();
            clsMuayene.GetReceteVeTani(muayene_Id, ref Recete, ref Tani);
            txtRecete.Text = Recete;
            txtTani.Text = Tani;
            txtDoktorAdi.Text = DoktorAdi;
            txtHastaTc.Text = HastaTc;
            txtHastaAdi.Text = HastaAdi;
            txtPoliklinik.Text = Poliklinik;
            txtMuayeneTarihi.Text = muayeneTarihi.ToShortDateString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            if (clsMuayene.SetReceteVeTani(int.Parse(txtMuayeneID.Text), txtRecete.Text, txtTani.Text)) {
                MessageBox.Show("Reçete ve tıbbi tanı eklendi", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Store.MessageError("Sisitemde Hata Olusturdu");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MuayeneSonucu_Load(object sender, EventArgs e)
        {

        }
    }
}
