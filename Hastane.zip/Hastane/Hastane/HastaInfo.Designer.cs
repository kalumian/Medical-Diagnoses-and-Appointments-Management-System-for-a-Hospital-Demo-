﻿namespace Hastane
{
    partial class HastaInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HastaInfo));
            this.hastaBilgiControl1 = new Hastane.HastaBilgiControl();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // hastaBilgiControl1
            // 
            this.hastaBilgiControl1.Location = new System.Drawing.Point(20, 17);
            this.hastaBilgiControl1.Name = "hastaBilgiControl1";
            this.hastaBilgiControl1.Size = new System.Drawing.Size(809, 377);
            this.hastaBilgiControl1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(675, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 53);
            this.button1.TabIndex = 37;
            this.button1.Text = "Kapat";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HastaInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 472);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hastaBilgiControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HastaInfo";
            this.Text = "Hasta Bilgileri";
            this.ResumeLayout(false);

        }

        #endregion

        private HastaBilgiControl hastaBilgiControl1;
        private System.Windows.Forms.Button button1;
    }
}