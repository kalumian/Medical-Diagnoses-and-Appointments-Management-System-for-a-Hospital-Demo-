﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class formControl : UserControl
    {
        public event Action<object> OnBtnCloseClick;

        protected virtual void BtnCloseClick(object sender)
        {
            Action<object> handler = OnBtnCloseClick;
            if (handler != null)
            {
                handler(sender);
            }
        }
        public event Action<object> OnBtnSaveClick;

        protected virtual void BtnSaveClick(object sender)
        {
            Action<object> handler = OnBtnSaveClick;
            if (handler != null)
            {
                handler(sender);
            }
        }
        public formControl()
        {
            InitializeComponent();
        }
        
        public bool BtnSaveEnable { get { return btnSave.Enabled; } set { btnSave.Enabled = value; } }
        
        private void button2_Click(object sender, EventArgs e)
        {
            if(OnBtnCloseClick != null)
            {
                OnBtnCloseClick(sender);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (OnBtnSaveClick != null)
            {
                OnBtnSaveClick(sender);
            }
        }
    }
}
