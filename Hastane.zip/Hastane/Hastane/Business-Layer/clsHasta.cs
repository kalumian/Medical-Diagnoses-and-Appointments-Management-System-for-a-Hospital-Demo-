﻿using Hastane.Database_Access_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Business_Layer
{
    internal class clsHasta
    {
      public string hasta_Tc { get; set; }
      public string hasta_Adi { get; set; }
      public string hasta_Soyadi{get;set;}
      public int cinsiyet_Id{get;set;}
      public DateTime dogum_tarihi{get;set;}
      public int medeni_durum_Id {get;set;}
      public int egitim_durumu_Id {get;set;}
      public int meslek_Id {get;set;}
      public int kan_grubu_Id {get;set;}
      public string telefon_no{get;set;}
      public string adres{get;set;}
      public Main.enMode Mode { get;set;}
        public clsHasta() {
            this.hasta_Tc = "";
            this.hasta_Adi = "";
            this.hasta_Soyadi = "";
            this.cinsiyet_Id = -1;
            this.dogum_tarihi = DateTime.Now;
            this.medeni_durum_Id = -1;
            this.egitim_durumu_Id = -1;
            this.meslek_Id = -1;
            this.kan_grubu_Id = -1;
            this.telefon_no = "";
            this.adres = "";
            this.Mode = Main.enMode.Add;
        }
        public clsHasta(
            
                string hasta_Tc,
                string hasta_Adi,
                string hasta_Soyadi,
                int cinsiyet_Id,
                DateTime dogum_tarihi,
                int medeni_durum_Id,
                int egitim_durumu_Id,
                int meslek_Id,
                int kan_grubu_Id,
                string telefon_no,
                string adres)
        {
            this.hasta_Tc = hasta_Tc;
            this.hasta_Adi = hasta_Adi;
            this.hasta_Soyadi = hasta_Soyadi;
            this.cinsiyet_Id = cinsiyet_Id;
            this.dogum_tarihi = dogum_tarihi;
            this.medeni_durum_Id = medeni_durum_Id;
            this.egitim_durumu_Id = egitim_durumu_Id;
            this.meslek_Id = meslek_Id;
            this.kan_grubu_Id = kan_grubu_Id;
            this.telefon_no = telefon_no;
            this.adres = adres;
            this.Mode = Main.enMode.Update;
        }
        static public DataTable GetAllHastalar()
        {
            return HastalarDataAccess.GetAllHastalar();
        }
        static public bool isExist(string hastaTc)
        {
            return HastalarDataAccess.isHastaExisit(hastaTc);
        }
        static public clsHasta Find(string hasta_Tc)
        {
                string hasta_Adi = "";
                string hasta_Soyadi = "";
                int cinsiyet_Id = -1;
                DateTime dogum_tarihi = DateTime.Now;
                int medeni_durum_Id = -1;
                int egitim_durumu_Id = -1;
                int meslek_Id = -1;
                int kan_grubu_Id = -1;
                string telefon_no = "";
                string adres = "";

            if (HastalarDataAccess.GetHastaBilgiByTc(
                hasta_Tc,
                ref hasta_Adi,
                ref hasta_Soyadi,
                ref cinsiyet_Id,
                ref dogum_tarihi,
                ref medeni_durum_Id,
                ref egitim_durumu_Id,
                ref meslek_Id,
                ref kan_grubu_Id,
                ref telefon_no,
                ref adres
                ))
            {
                return new clsHasta
                    (
                hasta_Tc,
                hasta_Adi,
                hasta_Soyadi,
                cinsiyet_Id,
                dogum_tarihi,
                medeni_durum_Id,
                egitim_durumu_Id,
                meslek_Id,
                kan_grubu_Id,
                telefon_no,
                adres
                    );
            }
            else
            {
                return null;
            }
        }
        private bool _AddHasta()
        {
            return HastalarDataAccess.AddHasta(
                hasta_Tc,
                hasta_Adi,
                hasta_Soyadi,
                cinsiyet_Id,
                dogum_tarihi,
                medeni_durum_Id,
                egitim_durumu_Id,
                meslek_Id,
                kan_grubu_Id,
                telefon_no,
                adres
                );
        }
        private bool _UpdateHasta()
        {
            return HastalarDataAccess._UpdateHasta(
                hasta_Tc,
                hasta_Adi,
                hasta_Soyadi,
                cinsiyet_Id,
                dogum_tarihi,
                medeni_durum_Id,
                egitim_durumu_Id,
                meslek_Id,
                kan_grubu_Id,
                telefon_no,
                adres
                );
        }
        static public bool DeleteHastaByTc(string hasta_Tc)
        {
            return HastalarDataAccess.DeleteHastaByTc(hasta_Tc);
        }
        static public bool HasMuayene(string hasta_Tc)
        {
            return HastalarDataAccess.HasMuayene(hasta_Tc); 
        }
        public bool Save()
        {
            switch(this.Mode)
            {
                case Main.enMode.Add:
                    if (_AddHasta())
                    {
                        this.Mode = Main.enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case Main.enMode.Update:
                        return _UpdateHasta();


            }
            return false;
        }
    }
}
