﻿using Hastane.Database_Access_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Business_Layer
{
    internal class clsDoktor
    {
       public string doktor_Tc { get; set; }
       public string doktor_Adi {get; set;}
       public string doktor_Soyadi {get; set;}
       public int poliklinik_Id {get; set;}
        static public DataTable GetAllDoktor()
        {
            return DoktorlarDataAccess.GetAllDoktorlar();
        }
        static public DataTable GetAllDoktorByPoliklinik(int Poliklinik_Id) {
            return DoktorlarDataAccess.GetAllDoktorByPoliklinik(Poliklinik_Id);
        }
    }
}
