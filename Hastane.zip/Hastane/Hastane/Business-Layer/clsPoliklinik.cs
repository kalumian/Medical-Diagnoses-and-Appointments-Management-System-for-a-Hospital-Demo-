﻿using Hastane.Database_Access_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hastane.Business_Layer
{
    internal class clsPoliklinik
    {
        static public DataTable GetAllPoliklinikler()
        {
            return PolikliniklerDataAccess.GetAllPoliklinikler();
        }
    }
}
