﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hastane.Database_Access_Layer;

namespace Hastane.Business_Layer
{
    public class clsMuayene
    {
        public clsMuayene() { 
        }
        static public bool SetReceteVeTani(int muayene_Id,string Recete, string Tani)
        {
           return MuyenelerDataAccess.SetReceteVeTani(muayene_Id,  Recete, Tani);
        }
        static public bool DeleteMuayene(int muayene_Id)
        {
            return MuyenelerDataAccess.DeleteMuayene(muayene_Id);
        }
        static public void GetReceteVeTani(int muayene_Id, ref string Recete, ref string Tani)
        {
            MuyenelerDataAccess.GetReceteVeTani(muayene_Id, ref Recete, ref Tani);
        }
        static public DataTable GetAllMuayene()
        {
            return MuyenelerDataAccess.GetAllMuayeneler();
        }
        static public int AddMuayene(
            string hasta_Tc,
            string doktor_Tc,
            DateTime muayene_tarihi
            )
        {
            return MuyenelerDataAccess.AddMuayene(hasta_Tc, doktor_Tc, muayene_tarihi);
        }
        static public bool UpdateMuayene(
        string hasta_Tc,
        string doktor_Tc,
        DateTime muayene_tarihi,
        int muayene_Id
        )
            {
                return MuyenelerDataAccess.UpdateMuayene(muayene_Id, hasta_Tc, doktor_Tc, muayene_tarihi);
            }
        }

}
