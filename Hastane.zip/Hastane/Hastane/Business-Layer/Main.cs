﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hastane.Database_Access_Layer;
namespace Hastane.Business_Layer
{
    internal class Main
    {
        public enum enMode
        {
            Update,
            Add
        }

        static internal DataTable getAllDataIntoDataTable(string Table_Name)
        {
            DataTable dt = new DataTable();

            // Validate the table name to avoid SQL Injection
            if (string.IsNullOrEmpty(Table_Name))
            {
                throw new ArgumentException("Invalid table name.");
            }

            SqlConnection connection = new SqlConnection(DatabaseSetting.ConnectionString);
            string query = $"select * from {Table_Name}";
            SqlCommand command = new SqlCommand(query, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                connection.Close();
            }
            return dt;

        }
        // --------------------------------------
        static public DataTable getMeslekler() {
            return getAllDataIntoDataTable("Meslek");
        }
        // --------------------------------------

        static public DataTable getEgitim_Durumlari(){
            return getAllDataIntoDataTable("Egitim_Durumu");
        }
        // --------------------------------------

        static public DataTable getKan_Grublari(){
            return getAllDataIntoDataTable("Kan_Grubu");  
        }
        // --------------------------------------

        static public DataTable getMedeni_durumlari(){
            return getAllDataIntoDataTable("Medeni_durum");  
        }
        // --------------------------------------

        static public DataTable getCinsiyetler(){
            return getAllDataIntoDataTable("Cinsiyet"); 
        }
    }
}
