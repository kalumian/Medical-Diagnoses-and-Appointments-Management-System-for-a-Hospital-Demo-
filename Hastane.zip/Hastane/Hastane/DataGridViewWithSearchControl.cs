﻿using Hastane.Business_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class DataGridViewWithSearchControl : UserControl
    {     
        public event Action<object> OnObjectAdded;

        protected virtual void ObjectAdded(object sender)
        {
            Action<object> handler = OnObjectAdded;
            if (handler != null)
            {
                handler(sender);
            }
        }
        public DataGridViewWithSearchControl()
        {
            InitializeComponent();
        }
        
        public DataGridViewSelectedRowCollection SelectedRows { get { return dataGridView.SelectedRows; } }
        public bool EnableAddButton { get { return btnAdd.Enabled; } set { btnAdd.Enabled = value; btnAdd.Visible = value; } }

        public ContextMenuStrip Strip
        {
            set { dataGridView.ContextMenuStrip = value; }
        }
        public void InitializeDataGridViewComponent(DataTable DataTable)
        {
            dataGridView.DataSource = DataTable;
            searchControl.InitializeSearchComponent(DataTable, dataGridView);
            searchControl.FilterFunction += UpdateDataGridViewFilter;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (OnObjectAdded != null && btnAdd.Enabled)
            {
                OnObjectAdded(this);
            }
        }

        
        private void UpdateDataGridViewFilter(DataView filteredView)
        {
            dataGridView.DataSource = filteredView;
        }
    }
}
