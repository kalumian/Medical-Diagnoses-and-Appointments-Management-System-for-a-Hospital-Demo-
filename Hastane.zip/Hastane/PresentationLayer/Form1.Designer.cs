﻿namespace PresentationLayer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnMuayene = new System.Windows.Forms.Button();
            this.btnPoliklinik = new System.Windows.Forms.Button();
            this.btnDoktorlar = new System.Windows.Forms.Button();
            this.btnHastalar = new System.Windows.Forms.Button();
            this.btnHakkimiz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMuayene
            // 
            this.btnMuayene.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMuayene.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuayene.Location = new System.Drawing.Point(509, 29);
            this.btnMuayene.Name = "btnMuayene";
            this.btnMuayene.Size = new System.Drawing.Size(369, 62);
            this.btnMuayene.TabIndex = 0;
            this.btnMuayene.Text = "Muayeneler";
            this.btnMuayene.UseVisualStyleBackColor = true;
            // 
            // btnPoliklinik
            // 
            this.btnPoliklinik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoliklinik.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPoliklinik.Location = new System.Drawing.Point(509, 116);
            this.btnPoliklinik.Name = "btnPoliklinik";
            this.btnPoliklinik.Size = new System.Drawing.Size(369, 62);
            this.btnPoliklinik.TabIndex = 1;
            this.btnPoliklinik.Text = "Poliklinik ";
            this.btnPoliklinik.UseVisualStyleBackColor = true;
            // 
            // btnDoktorlar
            // 
            this.btnDoktorlar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDoktorlar.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoktorlar.Location = new System.Drawing.Point(509, 203);
            this.btnDoktorlar.Name = "btnDoktorlar";
            this.btnDoktorlar.Size = new System.Drawing.Size(369, 62);
            this.btnDoktorlar.TabIndex = 2;
            this.btnDoktorlar.Text = "Doktorlar";
            this.btnDoktorlar.UseVisualStyleBackColor = true;
            // 
            // btnHastalar
            // 
            this.btnHastalar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHastalar.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHastalar.Location = new System.Drawing.Point(509, 290);
            this.btnHastalar.Name = "btnHastalar";
            this.btnHastalar.Size = new System.Drawing.Size(369, 62);
            this.btnHastalar.TabIndex = 3;
            this.btnHastalar.Text = "Hastalar";
            this.btnHastalar.UseVisualStyleBackColor = true;
            // 
            // btnHakkimiz
            // 
            this.btnHakkimiz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHakkimiz.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHakkimiz.Location = new System.Drawing.Point(509, 377);
            this.btnHakkimiz.Name = "btnHakkimiz";
            this.btnHakkimiz.Size = new System.Drawing.Size(369, 62);
            this.btnHakkimiz.TabIndex = 4;
            this.btnHakkimiz.Text = "Hakkimiz";
            this.btnHakkimiz.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(905, 477);
            this.Controls.Add(this.btnHakkimiz);
            this.Controls.Add(this.btnHastalar);
            this.Controls.Add(this.btnDoktorlar);
            this.Controls.Add(this.btnPoliklinik);
            this.Controls.Add(this.btnMuayene);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Hastane Sistem";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMuayene;
        private System.Windows.Forms.Button btnPoliklinik;
        private System.Windows.Forms.Button btnDoktorlar;
        private System.Windows.Forms.Button btnHastalar;
        private System.Windows.Forms.Button btnHakkimiz;
    }
}

