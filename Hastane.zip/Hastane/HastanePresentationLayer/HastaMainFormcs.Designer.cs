﻿namespace HastanePresentationLayer
{
    partial class HastalarMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HastalarMainForm));
            this.btnReturn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnAra = new System.Windows.Forms.Button();
            this.tbxSoyadi = new System.Windows.Forms.TextBox();
            this.tbxTarih = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxDoktor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxPoliklinik = new System.Windows.Forms.TextBox();
            this.labTC = new System.Windows.Forms.Label();
            this.lableMuayenelerSayfa = new System.Windows.Forms.Label();
            this.tbxTcNumarasi = new System.Windows.Forms.TextBox();
            this.btnMuayeneOlusturma = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnReturn.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(16, 742);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(341, 50);
            this.btnReturn.TabIndex = 32;
            this.btnReturn.Text = "Önceki Menüye Dön";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(393, 33);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(833, 759);
            this.dataGridView1.TabIndex = 36;
            // 
            // btnAra
            // 
            this.btnAra.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnAra.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAra.Location = new System.Drawing.Point(20, 605);
            this.btnAra.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(341, 50);
            this.btnAra.TabIndex = 28;
            this.btnAra.Text = "Ara";
            this.btnAra.UseVisualStyleBackColor = true;
            // 
            // tbxSoyadi
            // 
            this.tbxSoyadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxSoyadi.Location = new System.Drawing.Point(182, 223);
            this.tbxSoyadi.Name = "tbxSoyadi";
            this.tbxSoyadi.Size = new System.Drawing.Size(173, 30);
            this.tbxSoyadi.TabIndex = 22;
            // 
            // tbxTarih
            // 
            this.tbxTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxTarih.Location = new System.Drawing.Point(20, 542);
            this.tbxTarih.Name = "tbxTarih";
            this.tbxTarih.Size = new System.Drawing.Size(333, 28);
            this.tbxTarih.TabIndex = 27;
            this.tbxTarih.Value = new System.DateTime(2024, 5, 2, 21, 49, 37, 0);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(21, 507);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 25);
            this.label7.TabIndex = 35;
            this.label7.Text = "Doğum Tarihi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(177, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 25);
            this.label6.TabIndex = 34;
            this.label6.Text = "Soyadi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(11, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 25);
            this.label5.TabIndex = 33;
            this.label5.Text = "Medeni Durum ";
            // 
            // tbxDoktor
            // 
            this.tbxDoktor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxDoktor.Location = new System.Drawing.Point(14, 383);
            this.tbxDoktor.Name = "tbxDoktor";
            this.tbxDoktor.Size = new System.Drawing.Size(166, 30);
            this.tbxDoktor.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(19, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 25);
            this.label4.TabIndex = 31;
            this.label4.Text = "Adi";
            // 
            // tbxAdi
            // 
            this.tbxAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxAdi.Location = new System.Drawing.Point(18, 223);
            this.tbxAdi.Name = "tbxAdi";
            this.tbxAdi.Size = new System.Drawing.Size(158, 30);
            this.tbxAdi.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(15, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "Cinsiyet";
            // 
            // tbxPoliklinik
            // 
            this.tbxPoliklinik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxPoliklinik.Location = new System.Drawing.Point(16, 302);
            this.tbxPoliklinik.Name = "tbxPoliklinik";
            this.tbxPoliklinik.Size = new System.Drawing.Size(160, 30);
            this.tbxPoliklinik.TabIndex = 26;
            // 
            // labTC
            // 
            this.labTC.AutoSize = true;
            this.labTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labTC.Location = new System.Drawing.Point(17, 115);
            this.labTC.Name = "labTC";
            this.labTC.Size = new System.Drawing.Size(133, 25);
            this.labTC.TabIndex = 25;
            this.labTC.Text = "T.C Numarasi";
            // 
            // lableMuayenelerSayfa
            // 
            this.lableMuayenelerSayfa.AutoSize = true;
            this.lableMuayenelerSayfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lableMuayenelerSayfa.Location = new System.Drawing.Point(77, 33);
            this.lableMuayenelerSayfa.Name = "lableMuayenelerSayfa";
            this.lableMuayenelerSayfa.Size = new System.Drawing.Size(198, 54);
            this.lableMuayenelerSayfa.TabIndex = 24;
            this.lableMuayenelerSayfa.Text = "Hastalar";
            this.lableMuayenelerSayfa.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbxTcNumarasi
            // 
            this.tbxTcNumarasi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxTcNumarasi.Location = new System.Drawing.Point(16, 150);
            this.tbxTcNumarasi.Name = "tbxTcNumarasi";
            this.tbxTcNumarasi.Size = new System.Drawing.Size(337, 30);
            this.tbxTcNumarasi.TabIndex = 20;
            // 
            // btnMuayeneOlusturma
            // 
            this.btnMuayeneOlusturma.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnMuayeneOlusturma.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuayeneOlusturma.Location = new System.Drawing.Point(20, 673);
            this.btnMuayeneOlusturma.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnMuayeneOlusturma.Name = "btnMuayeneOlusturma";
            this.btnMuayeneOlusturma.Size = new System.Drawing.Size(341, 50);
            this.btnMuayeneOlusturma.TabIndex = 30;
            this.btnMuayeneOlusturma.Text = "Yeni Hasta Olustur";
            this.btnMuayeneOlusturma.UseVisualStyleBackColor = true;
            this.btnMuayeneOlusturma.Click += new System.EventHandler(this.btnMuayeneOlusturma_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(184, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 25);
            this.label2.TabIndex = 40;
            this.label2.Text = "Eğitim Durumu ";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.textBox2.Location = new System.Drawing.Point(187, 302);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(166, 30);
            this.textBox2.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(15, 433);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 25);
            this.label8.TabIndex = 44;
            this.label8.Text = "Telefon Numarasi";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.textBox3.Location = new System.Drawing.Point(19, 461);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(334, 30);
            this.textBox3.TabIndex = 43;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(184, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 25);
            this.label9.TabIndex = 42;
            this.label9.Text = "Kan Grubu";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.textBox4.Location = new System.Drawing.Point(191, 383);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(164, 30);
            this.textBox4.TabIndex = 41;
            // 
            // HastalarMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1239, 816);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnAra);
            this.Controls.Add(this.tbxSoyadi);
            this.Controls.Add(this.tbxTarih);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbxDoktor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbxAdi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbxPoliklinik);
            this.Controls.Add(this.labTC);
            this.Controls.Add(this.lableMuayenelerSayfa);
            this.Controls.Add(this.tbxTcNumarasi);
            this.Controls.Add(this.btnMuayeneOlusturma);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HastalarMainForm";
            this.Text = "Hastane Sistem - Hastalar";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAra;
        private System.Windows.Forms.TextBox tbxSoyadi;
        private System.Windows.Forms.DateTimePicker tbxTarih;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxDoktor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxPoliklinik;
        private System.Windows.Forms.Label labTC;
        private System.Windows.Forms.Label lableMuayenelerSayfa;
        private System.Windows.Forms.TextBox tbxTcNumarasi;
        private System.Windows.Forms.Button btnMuayeneOlusturma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox4;
    }
}