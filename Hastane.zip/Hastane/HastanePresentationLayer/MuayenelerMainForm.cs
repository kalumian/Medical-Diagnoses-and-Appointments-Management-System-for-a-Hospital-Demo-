﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastanePresentationLayer
{
    public partial class MuayenelerMainForm : Form
    {
        public MuayenelerMainForm()
        {
            InitializeComponent();
        }

        private void MuayenelerMainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAra_Click(object sender, EventArgs e)
        {

        }

        private void btnMuayeneOlusturma_Click(object sender, EventArgs e)
        {
            new MuayeneOlusturmaForm().ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
