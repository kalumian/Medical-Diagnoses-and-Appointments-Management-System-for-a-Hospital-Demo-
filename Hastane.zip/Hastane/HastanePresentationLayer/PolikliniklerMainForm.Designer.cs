﻿namespace HastanePresentationLayer
{
    partial class PolikliniklerMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PolikliniklerMainForm));
            this.btnReturn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnAra = new System.Windows.Forms.Button();
            this.labTC = new System.Windows.Forms.Label();
            this.lableMuayenelerSayfa = new System.Windows.Forms.Label();
            this.tbxTcNumarasi = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnReturn.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(30, 253);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(341, 50);
            this.btnReturn.TabIndex = 32;
            this.btnReturn.Text = "Önceki Menüye Dön";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(407, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(833, 729);
            this.dataGridView1.TabIndex = 36;
            // 
            // btnAra
            // 
            this.btnAra.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnAra.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAra.Location = new System.Drawing.Point(30, 186);
            this.btnAra.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(341, 50);
            this.btnAra.TabIndex = 28;
            this.btnAra.Text = "Ara";
            this.btnAra.UseVisualStyleBackColor = true;
            // 
            // labTC
            // 
            this.labTC.AutoSize = true;
            this.labTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labTC.Location = new System.Drawing.Point(31, 102);
            this.labTC.Name = "labTC";
            this.labTC.Size = new System.Drawing.Size(109, 31);
            this.labTC.TabIndex = 25;
            this.labTC.Text = "Poliklinik";
            // 
            // lableMuayenelerSayfa
            // 
            this.lableMuayenelerSayfa.AutoSize = true;
            this.lableMuayenelerSayfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lableMuayenelerSayfa.Location = new System.Drawing.Point(67, 19);
            this.lableMuayenelerSayfa.Name = "lableMuayenelerSayfa";
            this.lableMuayenelerSayfa.Size = new System.Drawing.Size(256, 54);
            this.lableMuayenelerSayfa.TabIndex = 24;
            this.lableMuayenelerSayfa.Text = "Poliklinikler";
            this.lableMuayenelerSayfa.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbxTcNumarasi
            // 
            this.tbxTcNumarasi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tbxTcNumarasi.Location = new System.Drawing.Point(30, 136);
            this.tbxTcNumarasi.Name = "tbxTcNumarasi";
            this.tbxTcNumarasi.Size = new System.Drawing.Size(341, 30);
            this.tbxTcNumarasi.TabIndex = 20;
            // 
            // PolikliniklerMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1262, 776);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnAra);
            this.Controls.Add(this.labTC);
            this.Controls.Add(this.lableMuayenelerSayfa);
            this.Controls.Add(this.tbxTcNumarasi);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PolikliniklerMainForm";
            this.Text = "Hastane Sistem - Poliklinikler";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAra;
        private System.Windows.Forms.Label labTC;
        private System.Windows.Forms.Label lableMuayenelerSayfa;
        private System.Windows.Forms.TextBox tbxTcNumarasi;
    }
}