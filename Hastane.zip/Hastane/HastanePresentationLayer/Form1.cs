﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastanePresentationLayer
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
            InitializeButtonClickEvents();
        }
        private void OpenOwnWindow(object sender, EventArgs e)
        {
            if(sender != null)
            {
                string Directory = ((Button)sender).Name;

                switch (Directory)
                {
                    case "btnMuayeneler":
                        new MuayenelerMainForm().ShowDialog();
                         break;
                    case "btnDoktorlar":
                        new DoktorlarMainForm().ShowDialog();
                        break;
                    case "btnHastalar":
                         new HastalarMainForm().ShowDialog();
                        break;
                    case "btnPoliklinikler":
                         new PolikliniklerMainForm().ShowDialog();
                        break;
                    case "btnHakkimiz":
                         new Hakkimiz().ShowDialog();
                        break;
            }

            }
        }

        private void SubscribeButtonClickEvent(Button button)
        {
            button.Click += OpenOwnWindow;
        }
        private void InitializeButtonClickEvents()
        {
            //SubscribeButtonClickEvent(btnMuayeneler);
            //SubscribeButtonClickEvent(btnDoktorlar);
            //SubscribeButtonClickEvent(btnHastalar);
            //SubscribeButtonClickEvent(btnPoliklinikler);
            //SubscribeButtonClickEvent(btnHakkimiz);
        }

        private void AnaSayfa_Resize(object sender, EventArgs e)
        {
            MainTapControl.Size = this.Size;
        }

        private void btnYeniMuayeneOlustur_Click(object sender, EventArgs e)
        {
           Form window = new MuayeneOlusturmaForm();
            window.Show(); 
        }
    }
}
