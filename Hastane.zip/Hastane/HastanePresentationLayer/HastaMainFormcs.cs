﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastanePresentationLayer
{
    public partial class HastalarMainForm : Form
    {
        public HastalarMainForm()
        {
            InitializeComponent();
        }

        private void btnMuayeneOlusturma_Click(object sender, EventArgs e)
        {
            new YeniHastaOlusturma().ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
